import javax.swing.*;
import java.awt.*;


public class Graphics {

    public static grapher grapher;

    public static void main(String[] args) {

        //Creating the window and drawing tool
        Window frame = new Window();
        frame.setDefaultCloseOperation(Window.EXIT_ON_CLOSE);
        frame.setBounds(500, 200, 500, 500);
        frame.setLayout(new BorderLayout());
        grapher = new grapher();

        //Configuring the Button
        JButton start = new JButton("Start");
        start.addActionListener(frame);
        start.setText("Start");
        
        //Panel borders settings
        frame.add( grapher, BorderLayout.CENTER);
        frame.add(start, BorderLayout.NORTH);
        
        frame.setVisible( true );
    }
}
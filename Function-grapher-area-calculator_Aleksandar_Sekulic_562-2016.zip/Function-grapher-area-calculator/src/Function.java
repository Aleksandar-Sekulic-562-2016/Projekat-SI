
public interface Function {
	public double f(double x);
}

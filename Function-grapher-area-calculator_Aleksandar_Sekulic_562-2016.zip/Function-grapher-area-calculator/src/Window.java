import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.event.ActionListener;


public class Window extends JFrame implements ActionListener{
	
	public static final double INCREMENT = 1E-4;

	public static double integral(double a, double b, Function function) {
        double area = 0;
        double modifier = 1;
        if(a > b) {
            double tempA = a;
            a = b;
            b = tempA;
            modifier = -1;
        }
        for(double i = a + INCREMENT; i < b; i += INCREMENT) {
            double dFromA = i - a;
            area += (INCREMENT / 2) * (function.f(a + dFromA) + function.f(a + dFromA - INCREMENT));
        }
        return (Math.round(area * 1000.0) / 1000.0) * modifier;
    }
	
    @Override
    public void actionPerformed(ActionEvent e) {

    	double[] k = new double[8];
    	
    	Integer[] options = {0, 1, 2, 3, 4, 5, 6, 7};
    	int n = (Integer)JOptionPane.showInputDialog(null, "Enter the polynomial rang:", 
                "Prime numbers", JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
    	
    	int i=0;
    	while(i<=n) {
    		try {
    			k[i] = Double.parseDouble(JOptionPane.showInputDialog(String.format("Enter x^%d coeficient:",  i)));
    			i++;
    		}
    		catch(Exception q) {
    			JOptionPane.showMessageDialog(null, "Enter a valid data type.");
    		}
    	}
    	
    	
    	
    	
    	Integer[] optionsBounds = {-100, -99, -98, -97, -96, -95, -94, -93, -92, -91,
    			-90, -89, -88, -87, -86, -85, -84, -83, -82, -81, 
    			-80, -79, -78, -77, -76, -75, -74, -73, -72, -71
    			-70, -69, -68, -67, -66, -65, -64, -63, -62, -61,
    			-60, -59, -58, -57, -56, -55, -54, -53, -52, -51,
    			-50, -49, -48, -47, -46, -45, -44, -43, -42, -41, 
    			-40, -39, -38, -37, -36, -35, -34, -33, -32, -31, 
    			-30, -29, -28, -27, -26, -25, -24, -23, -22, -21, 
    			-20, -19, -18, -17, -16, -15, -14, -13, -12, -11,
    			-10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 
    			0,
    			1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 
    			11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    			21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 
    			31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    			41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
    			51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
    			61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
    			71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    			81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
    			91, 92, 93, 94, 95, 96, 97, 98, 99, 100};
    	
    	
    	int lowb = (Integer)JOptionPane.showInputDialog(null, "Select the lower bound:", 
                "Lower bound", JOptionPane.QUESTION_MESSAGE, null, optionsBounds, optionsBounds[99]);
    	
	    int upb = (Integer)JOptionPane.showInputDialog(null, "Select the upper bound:", 
	            "Upper bound", JOptionPane.QUESTION_MESSAGE, null, optionsBounds, optionsBounds[100]);
    	
	    
    	Graphics.grapher.drawPolynome(Graphics.grapher.getGraphics(),
    			k[7], k[6], k[5], k[4], k[3], k[2], k[1], k[0], -750, 750);
    	
    	JOptionPane.showMessageDialog(null, "Surface area in given bounds is | " + 
    			Math.abs(integral(lowb, upb, new Function() {
	            @Override
	            public double f(double x) {
	                return Math.pow(x, 7)*k[7] + Math.pow(x, 6)*k[6] + Math.pow(x,5)*k[5] +
	                		Math.pow(4, x)*k[4] + Math.pow(3, x)*k[3] + Math.pow(2, x)*k[2] +
	                		x*k[1] + k[0];
	            }}
        )) + " |");
    }

}